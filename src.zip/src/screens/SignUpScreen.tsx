import {
  Image,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StatusBar,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import "../../global.css";
import { ALERT_TYPE, AlertNotificationRoot, Toast } from "react-native-alert-notification";
import { useTheme } from "../theme/ThemeProvider";
import { FloatingLabelInput } from "react-native-floating-label-input";
import { useState } from "react";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { RootStack } from "../../App";
import { useNavigation } from "@react-navigation/native";
import { useUserRegistration } from "../components/UserContext";
import { validateFirstName, validateLastName } from "../util/Validation";



type SignUpProps = NativeStackNavigationProp<RootStack,"SignUpScreen">;

export default function SignUpScreen() {
  const navigation = useNavigation<SignUpProps>();

 
  const { applied } = useTheme();

  const logo =
    applied === "light"
      ? require("../../assets/logo.png")
      : require("../../assets/lightLogo.png");

  const {userData,setUserData} = useUserRegistration();
  const [firstName,setFirstName] = useState("");
  const [lastName,setLastName]= useState("");

  return (
   
      <KeyboardAvoidingView
        behavior={Platform.OS === "android" ? "padding" : "height"}
        keyboardVerticalOffset={Platform.OS === "android" ? 100 : 100}
        className="flex-1 justify-center items-center"
      >
        <SafeAreaView className="justify-center items-center p-5">
          <StatusBar />
          <Image source={logo} className="h-40 w-36" />
          <View className="w-full justify-start items-start">
            <Text className="font-bold text-slate-500 ">
              Create your account and start the conversation today
            </Text>
          </View>

          <View className="self-stretch">
            <View className="w-full my-3">
              <FloatingLabelInput
                style={{ borderWidth: 2, borderColor: "black" }}
                label={"Enter your first name"}
                value={userData.firstName}
                onChangeText={(text)=>{

                  setUserData((previous)=>({
                      ...previous,
                      firstName:text,

                  }));

                }}
               
              />
            </View>
            <View className="w-full my-3">
              <FloatingLabelInput
                style={{ borderWidth: 2, borderColor: "black" }}
                label={"Enter your last name"}
                value={userData.lastName}
                onChangeText={(text)=>{
                  setUserData((previous)=>({
                    ...previous,
                    lastName:text,
                  }));
                }}
                
              />
            </View>
          </View>
        </SafeAreaView>
        <View className="mt-1 w-full px-5">
          <Pressable className="bg-green-600 h-14 justify-center items-center rounded-full"
          onPress={()=>{
           
           let validFirstName = validateFirstName(userData.firstName);
           let validLastName = validateLastName(userData.lastName);

           if(validFirstName){
            Toast.show({
              type:ALERT_TYPE.WARNING,
              title:"Warning",
              textBody:validFirstName,
            });
           }else if(validLastName){
             Toast.show({
              type:ALERT_TYPE.WARNING,
              title:"Warning",
              textBody:validLastName,
            });
           }else{
            navigation.navigate("ContactScreen");
           }
           

          }}
          >
            <Text className="text-slate-100  font-bold text-2xl">
              Next
            </Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
   
  );
}
