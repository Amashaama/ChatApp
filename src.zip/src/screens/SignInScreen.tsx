import { Text, View } from "react-native";

export default function SignInScreen(){
    
    return(
        <View>
            <Text>Hello SignIn</Text>
        </View>
    );
}