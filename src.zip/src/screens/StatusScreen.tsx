import { SafeAreaView } from "react-native-safe-area-context";

export default function StatusScreen(){
    return(
        <SafeAreaView></SafeAreaView>
    );

}