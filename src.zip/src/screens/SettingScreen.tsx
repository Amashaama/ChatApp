import { StatusBar, Text, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { ThemeOption, useTheme } from "../theme/ThemeProvider";

const options :ThemeOption[] =["light","dark","system"];


export default function SettingScreen(){

    const {preference,applied,setPrefernce} = useTheme();


    return(
     <SafeAreaView className="flex-1 items-center" edges={["right","bottom","left"]}>
        <StatusBar hidden={false} />
        <View className="flex-1 bg-red-50 p-5">
            <Text className="font-bold text-lg text-slate-900 dark:text-slate-100">
             Choose App Theme
            </Text>
            <View className="flex-row gap-x-3 mt-2">
            {options.map((option)=>(
                <TouchableOpacity
                key={option}
                className={`py-2 px-5 rounded-full mb-2 ${
                    preference === option ?"bg-green-600": "bg-gray-200"
                } 
                }`}
                onPress={()=>setPrefernce(option)}
                >
                    <Text
                     className={`text-center font-bold first-line:${
                        applied ==="dark" ? "border-slate-900" : "border-slate-900"
                     }`}
                    >
                        {option.charAt(0).toUpperCase()+option.slice(1)}

                    </Text>

                </TouchableOpacity>
            ))}

            </View>

        </View>
     </SafeAreaView>
    );
}