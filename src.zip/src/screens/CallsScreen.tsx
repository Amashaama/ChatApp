import { SafeAreaView } from "react-native-safe-area-context";

export default function CallsScreen(){
    return(
        <SafeAreaView></SafeAreaView>
    );

}