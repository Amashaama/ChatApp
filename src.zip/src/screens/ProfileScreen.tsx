import { View } from "react-native";

export default function ProfileScreen(){
    return(
        <View></View>
    );
}